package com.mobdeve.s14.pomogochi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

public class TodoListActivity extends AppCompatActivity {
    private ImageView iv_todo_list;
    private ImageButton ib_new;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_todo_list);

        iv_todo_list = findViewById(R.id.iv_todo_background);
        ib_new = findViewById(R.id.ib_todo_add);


        iv_todo_list.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toDoDetails();
            }
        });

        ib_new.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toAddList();
            }
        });

    }

    private void toDoDetails() {
        Intent toDoDetails = new Intent(this, ToDoDetailsActivity.class);
        startActivity(toDoDetails);
    }

    private void toAddList() {
        Intent toAddList = new Intent(this, ToDoDetailsActivity.class);
        startActivity(toAddList);
    }
}